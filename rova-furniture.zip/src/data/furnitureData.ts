import { Product, HeroSlide, QuadrantItem, ValuePillar, Testimonial, MetricStat } from '../types';

export const HERO_SLIDES: HeroSlide[] = [
  {
    id: 'hero-1',
    title: 'Aurelia Bouclé Lounge Chair',
    headline: 'Sculptural Elegance',
    category: 'Luxe Seating',
    tagline: 'Hand-stretched Italian oat bouclé paired with brushed brass spherical feet.',
    price: 1850,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1400&q=85',
    material: 'Premium Merino Bouclé & Brass',
    origin: 'Handcrafted in Milan, Italy',
    designer: 'Studio Rova Milan'
  },
  {
    id: 'hero-2',
    title: 'Svelto Fluted Travertine Table',
    headline: 'Architectural Monolith',
    category: 'Living Collection',
    tagline: 'Honed Roman travertine stone with organic fluting and soft rounded bevels.',
    price: 2400,
    image: 'https://images.unsplash.com/photo-1533779283484-84e1b8c04ec0?auto=format&fit=crop&w=1400&q=85',
    material: 'Natural Roman Travertine',
    origin: 'Tivoli, Italy',
    designer: 'Elena Rossi'
  },
  {
    id: 'hero-3',
    title: 'Solstice Minimal Brass Arc Lamp',
    headline: 'Ambient Luminescence',
    category: 'Lighting Gallery',
    tagline: 'Counterbalanced hand-spun champagne brass casting a warm 2700K sunset glow.',
    price: 1120,
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1400&q=85',
    material: 'Hand-Spun Brass & Frosted Opal Glass',
    origin: 'Copenhagen, Denmark',
    designer: 'Kasper Thomsen'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'rova-01',
    name: 'Aurelia Curved Bouclé Lounge',
    subtitle: 'Signature Ergonomic Silhouette',
    category: 'Seating',
    collection: 'Luxe Collection',
    price: 1850,
    originalPrice: 2100,
    rating: 4.9,
    reviewCount: 148,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1580481077190-736135653129?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'W 92cm × D 88cm × H 76cm (Seat: 42cm)',
    material: 'Triple-Density Foam, Italian Bouclé Wool, Solid Birch Frame',
    description: 'An organic embrace carved in sculptured bouclé. The Aurelia combines generous sweeping contours with ergonomic lumbar proportion, creating an oasis of restful calm in contemporary spaces.',
    badge: 'Bestseller',
    colorOptions: [
      { name: 'Oatmeal Bouclé', hex: '#EDE6DD' },
      { name: 'Espresso Wool', hex: '#2B2623' },
      { name: 'Warm Terracotta', hex: '#A86851' }
    ],
    features: [
      'Stain-resistant nano-treated virgin wool bouclé',
      'Solid FSC-certified kiln-dried internal hardwood structure',
      'High-resilience foam core with memory cushioning layer',
      'Concealed brass leveling glides'
    ],
    inStock: true
  },
  {
    id: 'rova-02',
    name: 'Svelto Honed Travertine Coffee Table',
    subtitle: 'Sculpted Monolithic Stone',
    category: 'Tables',
    collection: 'Sculptural Living',
    price: 2400,
    rating: 5.0,
    reviewCount: 89,
    image: 'https://images.unsplash.com/photo-1533779283484-84e1b8c04ec0?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1533779283484-84e1b8c04ec0?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'L 130cm × W 75cm × H 36cm',
    material: 'Natural Italian Travertine with Matte Satin Sealant',
    description: 'Cut from monolithic slabs of Roman travertine, each piece highlights individual geological fissures and natural crystalline deposits, finished with a velvet-matte tactile seal.',
    badge: 'Artisan Edit',
    colorOptions: [
      { name: 'Classic Warm Beige', hex: '#E2D8CC' },
      { name: 'Silver Vein Grey', hex: '#C2BBB2' }
    ],
    features: [
      'Individually hand-honed by master Italian stonemasons',
      'Food-safe, zero-luster anti-stain micro-sealant',
      'Beveled radius edge detail with subterranean pedestal base'
    ],
    inStock: true
  },
  {
    id: 'rova-03',
    name: 'Solstice Brass Floor Lamp',
    subtitle: 'Kinetic Counterbalance Arch',
    category: 'Lighting',
    collection: 'Architectural Lighting',
    price: 1120,
    originalPrice: 1280,
    rating: 4.8,
    reviewCount: 112,
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'Reach 145cm × Height 210cm × Base Ø 38cm',
    material: 'Solid Hand-Turned Brass & Mouth-Blown Matte Opaline Glass',
    description: 'A poetic curve of solid brushed brass that hovers weightlessly above seating areas. Features an integrated stepped foot dimmer and custom warm-spectrum LED core.',
    badge: 'New Release',
    colorOptions: [
      { name: 'Brushed Brass', hex: '#C5A880' },
      { name: 'Smoked Matte Black', hex: '#1E1E1E' },
      { name: 'Antique Bronze', hex: '#634E3A' }
    ],
    features: [
      'Rotatable 360-degree arm with frictionless brass joints',
      'Flicker-free CRI 98 ambient warm glow (2700K)',
      'Heavy cast marble stabilizing anchor inside base'
    ],
    inStock: true
  },
  {
    id: 'rova-04',
    name: 'Kanso Minimal Smoked Oak Credenza',
    subtitle: 'Japandi Linear Silhouette',
    category: 'Storage',
    collection: 'Organic Wood',
    price: 3100,
    rating: 4.9,
    reviewCount: 64,
    image: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'W 200cm × D 48cm × H 68cm',
    material: 'Quarter-Sawn European White Oak & Brass Reveal',
    description: 'Slatted tambour sliding doors glide effortlessly on hidden precision tracks. A recessed brass plinth elevates the architectural case, creating an illusion of weightlessness.',
    badge: 'Limited Run',
    colorOptions: [
      { name: 'Smoked Oak', hex: '#4A3B32' },
      { name: 'Natural Sand Oak', hex: '#D6C4B0' },
      { name: 'Charcoal Black', hex: '#222222' }
    ],
    features: [
      'Integrated soft-close acoustic sliding tambour slats',
      'Concealed cable management portals and adjustable shelves',
      'Hand-rubbed natural organic plant-oil finish'
    ],
    inStock: true
  },
  {
    id: 'rova-05',
    name: 'Vesper Modular Belgian Linen Sofa',
    subtitle: 'Deep-Comfort Architectural Seating',
    category: 'Seating',
    collection: 'Luxe Collection',
    price: 4600,
    rating: 4.95,
    reviewCount: 97,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'W 290cm × D 110cm × H 72cm (Seat: 40cm)',
    material: 'Master of Linen® Belgian Flax & Duck Down Quilted Cushions',
    description: 'Relaxed refinement embodied in generous proportions. Generous down-feather topper pillows rest atop an engineered dual-spring core for cloud-like support that keeps its tailoring.',
    badge: 'Flagship',
    colorOptions: [
      { name: 'Oatmeal Natural Linen', hex: '#DFD8CE' },
      { name: 'Bone White', hex: '#ECE8E1' },
      { name: 'Washed Slate', hex: '#686B6D' }
    ],
    features: [
      'Removable dry-cleanable linen covers with double-stitched French seams',
      'Dual-layer pocket spring & cruelty-free down-blend fill',
      'Modular connecting brackets for custom living room configurations'
    ],
    inStock: true
  },
  {
    id: 'rova-06',
    name: 'Numen Sculptural Ceramic Vessel & Pedestal',
    subtitle: 'Limited Studio Artifact',
    category: 'Objects',
    collection: 'Sculptural Living',
    price: 780,
    rating: 4.85,
    reviewCount: 52,
    image: 'https://images.unsplash.com/photo-1616046229478-9901c5536a45?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1616046229478-9901c5536a45?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=85'
    ],
    dimensions: 'Ø 34cm × H 55cm',
    material: 'Raw Stoneware Ceramic with Volcanic Ash Slip',
    description: 'Wheel-thrown and hand-carved with rhythmic fluting before receiving a high-fire reduction glaze. Serves as both functional art and a focal anchor for quiet corners.',
    badge: 'Unique Piece',
    colorOptions: [
      { name: 'Raw Chalk', hex: '#EAE6DF' },
      { name: 'Terracotta Earth', hex: '#A36049' },
      { name: 'Carbon Ash', hex: '#343332' }
    ],
    features: [
      'Hand-signed and stamped by master ceramist',
      'Waterproof vitrified interior liner for botanical stems',
      'Textured volcanic tactile grain'
    ],
    inStock: true
  }
];

export const QUADRANT_ITEMS: QuadrantItem[] = [
  {
    id: 'quad-1',
    title: 'The Curved Armchair',
    subtitle: 'Organic Fluidity',
    category: 'Seating Architecture',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=85',
    material: 'Textured Bouclé',
    description: 'Continuous ergonomic form molded without visible hard seams.',
    tag: 'Q1 · Ergonomics'
  },
  {
    id: 'quad-2',
    title: 'Travertine Plinth',
    subtitle: 'Geological Gravity',
    category: 'Mineral Artifacts',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=85',
    material: 'Italian Stone',
    description: 'Honed porous natural stone capturing millions of years in quiet beauty.',
    tag: 'Q2 · Solidity'
  },
  {
    id: 'quad-3',
    title: 'Atmospheric Arch',
    subtitle: 'Linear Brass',
    category: 'Luminous Design',
    image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=800&q=85',
    material: 'Champagne Brass',
    description: 'Architectural lighting calibrated to cast soothing warm reflections.',
    tag: 'Q3 · Illumination'
  },
  {
    id: 'quad-4',
    title: 'Smoked Oak Credenza',
    subtitle: 'Tactile Woodwork',
    category: 'Master Joinery',
    image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=800&q=85',
    material: 'European Oak',
    description: 'Dovetailed joinery crafted from century-old sustainably harvested forests.',
    tag: 'Q4 · Heritage'
  }
];

export const VALUE_PILLARS: ValuePillar[] = [
  {
    id: 'pillar-1',
    number: '01',
    title: 'Premium Quality Materials',
    shortDesc: 'Sourced directly from heritage quarries & historic European weaving mills.',
    fullDesc: 'We exclusively harvest certified Roman travertine, Italian virgin bouclé wool, and hand-patinated solid brass. Every material is chosen to develop a richer patina over decades.',
    iconName: 'Gem',
    highlight: 'Hand-picked raw minerals & textiles'
  },
  {
    id: 'pillar-2',
    number: '02',
    title: 'Eco-Friendly Manufacturing',
    shortDesc: '100% FSC-certified hardwoods, zero-VOC plant finishes, and carbon-neutral freight.',
    fullDesc: 'Circular engineering is woven into our core. Our packaging is 100% biodegradable and our production facilities run entirely on renewable solar and geothermal energy.',
    iconName: 'Leaf',
    highlight: '100% Carbon-neutral craft'
  },
  {
    id: 'pillar-3',
    number: '03',
    title: 'Innovative Design',
    shortDesc: 'Harmonious geometric silhouettes engineered for supreme ergonomic tranquility.',
    fullDesc: 'Designed at the intersection of Scandinavian minimalism and Italian modernism. Every curve is mathematically tested to support natural human posture without visual noise.',
    iconName: 'Sparkles',
    highlight: 'Award-winning architectural form'
  },
  {
    id: 'pillar-4',
    number: '04',
    title: 'Artisan Craftsmanship',
    shortDesc: 'Finished by generational master artisans with individual serial certificates.',
    fullDesc: 'No mass production shortcuts. Each piece passes through specialized craft ateliers in Milan, Copenhagen, and Porto, undergoing a 32-point inspection before dispatch.',
    iconName: 'ShieldCheck',
    highlight: 'Lifetime structural guarantee'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Clarissa Montgomery',
    role: 'Principal Architect at Studio Mont',
    location: 'Geneva, Switzerland',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    quote: 'Rova has achieved the impossible balance between brutalist restraint and absolute domestic warmth. The Aurelia armchair transformed our penthouse project into a sanctuary.',
    purchasedProduct: 'Aurelia Curved Bouclé Lounge',
    date: 'Verified Collector · Oct 2025'
  },
  {
    id: 'test-2',
    name: 'Julian Vance-Moreau',
    role: 'Interior Design Director',
    location: 'London, UK',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    quote: 'The craftsmanship of the Svelto Travertine table is unmatched. The stone has an incredible geological depth and velvety texture that photographs can barely capture.',
    purchasedProduct: 'Svelto Fluted Travertine Table',
    date: 'Verified Trade Member · Nov 2025'
  },
  {
    id: 'test-3',
    name: 'Seraphina Lin',
    role: 'Art Collector & Homeowner',
    location: 'Tokyo & San Francisco',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    quote: 'From unboxing the crate to white-glove assembly, Rova delivers an immaculate luxury experience. The minimalist brass lighting casts the most mesmerizing sunset glow.',
    purchasedProduct: 'Solstice Brass Floor Lamp',
    date: 'Verified Collector · Jan 2026'
  }
];

export const METRIC_STATS: MetricStat[] = [
  {
    value: '4.9/5',
    label: 'Verified Reviews',
    detail: 'From over 4,800 interior collectors worldwide'
  },
  {
    value: '20K+',
    label: 'Spaces Transformed',
    detail: 'Across 34 countries and bespoke architectural residences'
  },
  {
    value: '96.7%',
    label: 'Client Satisfaction',
    detail: 'Repeat commission and referral rating'
  },
  {
    value: '10+',
    label: 'Proven Experience',
    detail: 'Decade of pioneering slow-craft sustainable luxury'
  }
];
