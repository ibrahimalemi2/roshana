import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Eye, ShieldCheck, Sparkles } from 'lucide-react';
import { HERO_SLIDES } from '../data/furnitureData';
import { Product } from '../types';

interface HeroSectionProps {
  onExploreClick: () => void;
  onQuickView: (product: Product) => void;
  products: Product[];
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onQuickView,
  products
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const currentSlide = HERO_SLIDES[currentSlideIndex];

  // Auto slide rotation when not hovered
  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6500);
    return () => clearInterval(interval);
  }, [isHovered]);

  const nextSlide = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  // Find corresponding product for quick view
  const matchingProduct = products.find(p => p.name.includes(currentSlide.title.split(' ')[0])) || products[0];

  return (
    <section id="hero" className="relative min-h-[90vh] lg:min-h-[94vh] bg-[#F9F6F0] flex items-center overflow-hidden border-b border-[#E6DFD5]">
      {/* Ambient background glow & grid lines */}
      <div className="absolute inset-0 ambient-glow pointer-events-none" />
      <div className="absolute top-0 right-1/2 w-px h-full bg-[#E6DFD5]/60 hidden lg:block" />

      <div className="max-w-7xl mx-auto w-full px-6 lg:px-12 py-12 lg:py-20 z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* LEFT COLUMN: Editorial Typography & Brand Watermark */}
          <div className="lg:col-span-6 flex flex-col justify-between relative z-10">
            {/* Top pill */}
            <div className="inline-flex items-center gap-2 self-start px-3.5 py-1.5 rounded-full bg-[#EFE9DE] border border-[#DDD6CB] text-[#78634A] text-xs font-medium tracking-wider mb-6">
              <span className="w-2 h-2 rounded-full bg-[#C5A880] animate-ping" />
              <span className="uppercase tracking-[0.2em] text-[11px] font-semibold">2026 Architectural Living Capsule</span>
            </div>

            {/* Primary Editorial Heading with Italicized Flowing Contrast */}
            <div className="space-y-4 mb-8">
              <h1 className="font-serif-heading text-4xl sm:text-5xl md:text-6xl lg:text-[68px] leading-[1.08] text-[#1A1A1A] font-normal tracking-tight">
                Furniture That <br />
                <span className="italic font-normal font-serif-heading text-[#8C7355] hover:text-[#1A1A1A] transition-colors">
                  Defines
                </span>{' '}
                your space.
              </h1>

              <p className="font-sans-body text-base sm:text-lg text-[#1A1A1A]/75 font-light leading-relaxed max-w-lg">
                Where design meets lifestyle in perfect harmony. Sculptural silhouettes, honest organic minerals, and timeless European craftsmanship tailored for meditative living.
              </p>
            </div>

            {/* CTA Buttons & Micro specs */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 mb-12">
              <button
                onClick={onExploreClick}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-[#1A1A1A] text-[#F9F6F0] rounded-full text-sm font-medium tracking-wider uppercase transition-all duration-300 hover:bg-[#333333] hover:shadow-lg hover:shadow-black/10 active:scale-95 focus:outline-none"
              >
                <span>Explore Our Collection</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform text-[#C5A880]" />
              </button>

              <button
                onClick={() => onQuickView(matchingProduct)}
                className="inline-flex items-center gap-2 text-sm font-medium text-[#1A1A1A] hover:text-[#8C7355] transition-colors py-3 px-2 border-b border-transparent hover:border-[#8C7355]"
              >
                <Eye className="w-4 h-4 text-[#8C7355]" />
                <span>Quick Specification</span>
              </button>
            </div>

            {/* Subtle Brand Watermark stretching across bottom-left */}
            <div className="relative pt-4 overflow-hidden select-none pointer-events-none">
              <div className="font-serif-heading text-[120px] sm:text-[150px] md:text-[180px] font-bold tracking-tighter text-[#1A1A1A]/[0.05] leading-none uppercase -ml-3">
                rova
              </div>
            </div>

            {/* Quality Seals */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#E6DFD5] text-xs font-sans-body text-[#1A1A1A]/70">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                <span>100% Solid FSC Woods</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                <span>Roman Travertine</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#C5A880]" />
                <span>White-Glove Delivery</span>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Featured Product Image Card with Pagination Dots */}
          <div 
            className="lg:col-span-6 relative"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {/* Main Showcase Card Container */}
            <div className="relative bg-[#EDE6DD] rounded-[24px] lg:rounded-[32px] overflow-hidden p-3 sm:p-4 shadow-xl shadow-black/5 border border-[#E0D7CB] transition-all duration-500">
              
              {/* Product Visual Container with Aspect Ratio */}
              <div className="relative aspect-[4/5] sm:aspect-[4/4.5] w-full rounded-[20px] lg:rounded-[26px] overflow-hidden bg-[#E2D8CC] group">
                <img
                  src={currentSlide.image}
                  alt={currentSlide.title}
                  className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 ease-out"
                />

                {/* Ambient vignette overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent pointer-events-none" />

                {/* Top Floating Pill: Category & Price */}
                <div className="absolute top-5 left-5 right-5 flex items-center justify-between z-10">
                  <span className="px-3.5 py-1.5 rounded-full bg-[#F9F6F0]/90 backdrop-blur-md text-[11px] uppercase tracking-wider font-semibold text-[#1A1A1A] border border-white/40 shadow-xs">
                    {currentSlide.category}
                  </span>

                  <span className="px-4 py-1.5 rounded-full bg-[#1A1A1A]/85 backdrop-blur-md text-xs font-serif-heading font-medium text-[#F9F6F0] tracking-wide border border-white/10 shadow-xs">
                    ${currentSlide.price.toLocaleString()} USD
                  </span>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-6 left-6 right-6 text-[#F9F6F0] z-10">
                  <p className="text-[11px] uppercase tracking-[0.2em] text-[#C5A880] font-medium mb-1">
                    {currentSlide.headline}
                  </p>
                  <h2 className="font-serif-heading text-2xl sm:text-3xl font-medium tracking-tight mb-2">
                    {currentSlide.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-300 font-sans-body font-light line-clamp-2 mb-4 max-w-md">
                    {currentSlide.tagline}
                  </p>

                  <div className="flex items-center justify-between pt-3 border-t border-white/20 text-xs">
                    <span className="text-neutral-300">{currentSlide.material}</span>
                    <button
                      onClick={() => onQuickView(matchingProduct)}
                      className="inline-flex items-center gap-1.5 text-[#C5A880] hover:text-white font-medium transition-colors"
                    >
                      <span>View Specifications</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Prev / Next Slide Arrows */}
                <button
                  onClick={prevSlide}
                  aria-label="Previous slide"
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#F9F6F0]/80 hover:bg-[#F9F6F0] text-[#1A1A1A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-md backdrop-blur-xs"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <button
                  onClick={nextSlide}
                  aria-label="Next slide"
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#F9F6F0]/80 hover:bg-[#F9F6F0] text-[#1A1A1A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-md backdrop-blur-xs"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Bottom Carousel Controls & Pagination Dots */}
              <div className="pt-4 pb-2 px-3 flex items-center justify-between">
                {/* Numbered slide indicator */}
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-serif-heading font-medium text-[#1A1A1A]">
                    0{currentSlideIndex + 1}
                  </span>
                  <span className="text-xs text-neutral-400">/</span>
                  <span className="text-xs font-serif-heading text-neutral-400">
                    0{HERO_SLIDES.length}
                  </span>
                </div>

                {/* Pagination Dots */}
                <div className="flex items-center space-x-2.5">
                  {HERO_SLIDES.map((slide, idx) => (
                    <button
                      key={slide.id}
                      onClick={() => setCurrentSlideIndex(idx)}
                      aria-label={`Go to slide ${idx + 1}`}
                      className={`transition-all duration-300 rounded-full ${
                        currentSlideIndex === idx
                          ? 'w-8 h-2 bg-[#1A1A1A]'
                          : 'w-2 h-2 bg-[#1A1A1A]/25 hover:bg-[#1A1A1A]/50'
                      }`}
                    />
                  ))}
                </div>

                {/* Origin / Studio label */}
                <span className="text-[11px] text-[#8C7355] font-sans-body tracking-wider uppercase font-medium hidden sm:inline-block">
                  {currentSlide.origin}
                </span>
              </div>
            </div>

            {/* Decorative Offset Floating Card */}
            <div className="hidden sm:flex absolute -bottom-6 -left-8 bg-[#F9F6F0] border border-[#E0D7CB] rounded-2xl p-4 shadow-xl items-center gap-3.5 z-20 animate-bounce duration-1000 max-w-xs">
              <div className="w-10 h-10 rounded-xl bg-[#EDE6DD] flex items-center justify-center text-[#8C7355]">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-[#8C7355] font-semibold">Artisanal Edition</p>
                <p className="text-xs font-medium text-[#1A1A1A]">Bespoke Made to Order in 4-6 Weeks</p>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
