import React, { useState } from 'react';
import { Search, X, Star, ArrowRight, Eye } from 'lucide-react';
import { Product } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');

  const filtered = query.trim() === ''
    ? products
    : products.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase()) ||
        p.material.toLowerCase().includes(query.toLowerCase()) ||
        p.collection.toLowerCase().includes(query.toLowerCase())
      );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 md:p-12 overflow-y-auto bg-black/60 backdrop-blur-xs animate-fadeIn">
      {/* Backdrop close */}
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative bg-[#FAF7F2] w-full max-w-2xl rounded-[28px] overflow-hidden shadow-2xl border border-[#DFD3C2] z-10 p-6 sm:p-8 space-y-6">
        
        {/* Search input header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#E6DFD5]">
          <div className="flex items-center gap-3 flex-1">
            <Search className="w-5 h-5 text-[#8C7355]" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, stone, wood, or category..."
              className="w-full bg-transparent text-[#1A1A1A] font-serif-heading text-xl placeholder-neutral-400 focus:outline-none"
            />
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#EFE8DD] text-neutral-500 hover:text-black transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Tags */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-neutral-400 font-sans-body">Popular:</span>
          {['Travertine', 'Bouclé', 'Oak', 'Lighting', 'Lounge'].map((tag) => (
            <button
              key={tag}
              onClick={() => setQuery(tag)}
              className="px-3 py-1 rounded-full bg-[#EDE6DD] hover:bg-[#E2D8CC] text-[#1A1A1A] transition-colors"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto space-y-3 pr-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-neutral-500 text-sm font-sans-body">
              No pieces match "{query}". Try searching for travertine, seating, or lamp.
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectProduct(item);
                  onClose();
                }}
                className="group cursor-pointer p-3.5 rounded-2xl bg-white hover:bg-[#FAF7F2] border border-[#E8DFCFA0] hover:border-[#8C7355] flex items-center justify-between transition-all duration-200"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 rounded-xl object-cover bg-[#ECE4D8]"
                  />
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-[#8C7355] font-semibold">
                      {item.collection}
                    </span>
                    <h4 className="font-serif-heading text-lg font-medium text-[#1A1A1A] group-hover:text-[#8C7355] transition-colors">
                      {item.name}
                    </h4>
                    <p className="text-xs text-neutral-500 line-clamp-1">{item.material}</p>
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <span className="font-serif-heading text-base font-semibold text-[#1A1A1A]">
                    ${item.price.toLocaleString()}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-[#EDE6DD] group-hover:bg-[#1A1A1A] group-hover:text-[#F9F6F0] flex items-center justify-center transition-colors">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
