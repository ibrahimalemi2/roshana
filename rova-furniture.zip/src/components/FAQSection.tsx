import React, { useState } from 'react';
import { ChevronDown, MessageSquare, Phone, Mail, HelpCircle, Clock } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const FAQS: FAQItem[] = [
  {
    question: 'How is white-glove delivery and installation handled?',
    answer: 'Every Rova furniture delivery is executed by our certified two-person specialist courier team. They schedule a precise 2-hour delivery window, unpack the bespoke wooden transport crate in your room of choice, assemble all brass and stone components, and remove all 100% recyclable packing materials.',
    category: 'Logistics'
  },
  {
    question: 'Can I request bespoke dimensional adjustments or custom fabric finishes?',
    answer: 'Yes. Our Milan design studio offers custom scaling on credenzas, dining tables, and sectional configurations. We also supply custom upholstery from Rubelli, Kvadrat, and certified virgin Belgian linen mills for certified trade architects and private clients.',
    category: 'Customization'
  },
  {
    question: 'How do I care for natural Roman Travertine and oiled Smoked Oak?',
    answer: 'Our travertine is sealed with a breathable food-safe matte hydrophobic treatment. Clean daily with a damp microfiber cloth and mild pH-neutral soap. We include a complimentary Rova Organic Beeswax Maintenance Elixir with every solid oak and travertine piece to nurture the natural patina over decades.',
    category: 'Care'
  },
  {
    question: 'What is the Rova Lifetime Structural Guarantee?',
    answer: 'We guarantee all internal solid hardwood frames, mortise-and-tenon joinery, and solid brass structural components for life against structural failure or manufacturing defects. Each piece is issued with an individual engraved brass serial plaque and digital certificate of authenticity.',
    category: 'Guarantee'
  },
  {
    question: 'Do you offer physical material and swatch sample boxes?',
    answer: 'Yes. You may request our Curated Swatch Archive containing hand-cut Roman travertine, smoked oak blocks, and 6 bouclé/linen swatches. The cost of the swatch box ($45) is fully credited toward your first furniture commission.',
    category: 'Samples'
  }
];

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-[#F9F6F0] border-b border-[#E6DFD5] relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Left Column: Title and Concierge Card */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE8DD] text-[#7A644C] text-[11px] uppercase tracking-[0.2em] font-semibold mb-3">
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Atelier Inquiries</span>
              </div>
              <h2 className="font-serif-heading text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1A1A] tracking-tight">
                Frequently Asked <br />
                <span className="italic font-serif-heading text-[#8C7355]">Questions</span>
              </h2>
              <p className="mt-4 font-sans-body text-sm text-[#1A1A1A]/70 font-light leading-relaxed">
                Clear answers regarding our white-glove transport, custom architectural scaling, material longevity, and warranty coverage.
              </p>
            </div>

            {/* Concierge Box */}
            <div className="bg-[#FAF7F2] p-8 rounded-[24px] border border-[#DFD3C2] shadow-sm space-y-6">
              <h3 className="font-serif-heading text-2xl text-[#1A1A1A]">
                Dedicated Client Concierge
              </h3>
              <p className="text-xs text-[#1A1A1A]/70 font-sans-body leading-relaxed">
                Need guidance on dimensions, room floorplan flow, or trade discounts? Our interior advisory team in Milan is available for private appointments.
              </p>

              <div className="space-y-3 pt-2">
                <a
                  href="mailto:concierge@rova-atelier.com"
                  className="flex items-center gap-3 text-xs text-[#1A1A1A] hover:text-[#8C7355] font-medium transition-colors"
                >
                  <Mail className="w-4 h-4 text-[#8C7355]" />
                  <span>concierge@rova-atelier.com</span>
                </a>
                <div className="flex items-center gap-3 text-xs text-[#1A1A1A]/80">
                  <Clock className="w-4 h-4 text-[#8C7355]" />
                  <span>Mon–Sat: 9:00 AM – 7:00 PM CET</span>
                </div>
              </div>

              <a
                href="mailto:concierge@rova-atelier.com?subject=Rova%20Private%20Design%20Consultation"
                className="block w-full text-center py-3.5 px-4 bg-[#1A1A1A] text-[#F9F6F0] rounded-full text-xs font-medium uppercase tracking-wider hover:bg-[#333333] transition-colors"
              >
                Schedule Private Consultation
              </a>
            </div>
          </div>

          {/* Right Column: FAQ Accordion */}
          <div className="lg:col-span-7 space-y-4">
            {FAQS.map((faq, index) => {
              const isOpen = openIndex === index;

              return (
                <div
                  key={index}
                  className={`rounded-[20px] border transition-all duration-300 overflow-hidden ${
                    isOpen
                      ? 'bg-[#FAF7F2] border-[#8C7355] shadow-md'
                      : 'bg-[#FAF7F2]/60 border-[#E2D8CC] hover:bg-[#FAF7F2]'
                  }`}
                >
                  <button
                    onClick={() => toggleFAQ(index)}
                    className="w-full text-left p-6 sm:p-7 flex items-center justify-between gap-4 focus:outline-none"
                  >
                    <span className="font-serif-heading text-lg sm:text-xl font-medium text-[#1A1A1A]">
                      {faq.question}
                    </span>
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ${
                        isOpen ? 'bg-[#1A1A1A] text-[#F9F6F0] rotate-180' : 'bg-[#EFE8DD] text-[#1A1A1A]'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-6 sm:px-7 pb-6 pt-0 border-t border-[#E6DFD5]/60 animate-fadeIn">
                      <p className="font-sans-body text-xs sm:text-sm text-[#1A1A1A]/75 font-light leading-relaxed pt-4">
                        {faq.answer}
                      </p>
                      <div className="mt-4 inline-block px-2.5 py-1 rounded-full bg-[#EAE2D5] text-[10px] uppercase tracking-wider font-semibold text-[#8C7355]">
                        {faq.category}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
