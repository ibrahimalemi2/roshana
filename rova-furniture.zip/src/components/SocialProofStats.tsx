import React from 'react';
import { Star, Quote, CheckCircle2, Award, Sparkles, Building2, Globe2 } from 'lucide-react';
import { TESTIMONIALS, METRIC_STATS } from '../data/furnitureData';

export const SocialProofStats: React.FC = () => {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-[#F4EFE6] border-b border-[#E6DFD5] relative overflow-hidden">
      
      {/* Background ambient accents */}
      <div className="absolute -top-40 right-0 w-96 h-96 rounded-full bg-[#E8DFD0]/40 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E8DFD0] text-[#7A644C] text-[11px] uppercase tracking-[0.2em] font-semibold mb-3">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>Collector Perspectives</span>
          </div>

          <h2 className="font-serif-heading text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1A1A] tracking-tight">
            Loved by Architects & <br />
            <span className="italic font-serif-heading text-[#8C7355]">Discerning Homeowners</span>
          </h2>

          <p className="mt-4 font-sans-body text-sm sm:text-base text-[#1A1A1A]/70 font-light">
            Read authentic words from interior designers, architects, and private collectors who have transformed their spaces with Rova.
          </p>
        </div>

        {/* Testimonials 3-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {TESTIMONIALS.map((test) => (
            <div
              key={test.id}
              className="bg-[#FAF7F2] rounded-[24px] p-8 border border-[#DFD3C2] shadow-sm hover:shadow-xl hover:border-[#C5A880] transition-all duration-300 flex flex-col justify-between relative group"
            >
              <div className="space-y-4">
                {/* Rating Stars & Quote Icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-[#C5A880]">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-[#E2D8CC] group-hover:text-[#C5A880]/40 transition-colors" />
                </div>

                {/* Quote text */}
                <p className="font-serif-heading text-lg sm:text-xl text-[#1A1A1A] font-normal leading-relaxed italic">
                  "{test.quote}"
                </p>
              </div>

              {/* Author Info */}
              <div className="pt-6 mt-6 border-t border-[#E6DFD5] flex items-center gap-4">
                <img
                  src={test.avatar}
                  alt={test.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#E2D8CC]"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-xs font-semibold text-[#1A1A1A]">
                      {test.name}
                    </h3>
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#8C7355]" />
                  </div>
                  <p className="text-[11px] text-[#8C7355] font-sans-body">
                    {test.role}
                  </p>
                  <p className="text-[10px] text-neutral-400 font-sans-body mt-0.5">
                    {test.location} · {test.purchasedProduct}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* 4-Column Metrics Counter Grid */}
        <div className="bg-[#1A1A1A] text-[#F9F6F0] rounded-[28px] p-8 sm:p-12 border border-[#2E2E2E] shadow-2xl relative overflow-hidden">
          {/* Subtle metallic brass top border line */}
          <div className="absolute top-0 inset-x-0 h-1 brass-gradient" />

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 divide-y lg:divide-y-0 lg:divide-x divide-neutral-800">
            {METRIC_STATS.map((metric, idx) => (
              <div
                key={idx}
                className={`flex flex-col justify-center text-center px-4 ${
                  idx > 0 ? 'pt-6 lg:pt-0' : ''
                }`}
              >
                {/* Metric Value */}
                <span className="font-serif-heading text-4xl sm:text-5xl lg:text-6xl font-light tracking-tight text-white mb-2">
                  <span className="text-[#C5A880]">{metric.value}</span>
                </span>

                {/* Metric Label */}
                <h4 className="text-xs sm:text-sm font-semibold tracking-wider uppercase text-neutral-200 mb-1">
                  {metric.label}
                </h4>

                {/* Detail */}
                <p className="text-[11px] text-neutral-400 font-sans-body max-w-[200px] mx-auto font-light leading-snug">
                  {metric.detail}
                </p>
              </div>
            ))}
          </div>

          {/* Bottom Press & Architecture Accreditations */}
          <div className="mt-10 pt-8 border-t border-neutral-800/80 flex flex-wrap items-center justify-center gap-8 sm:gap-14 text-neutral-400 text-xs font-serif-heading tracking-widest uppercase">
            <span className="hover:text-white transition-colors">Architectural Digest</span>
            <span className="hidden sm:inline text-neutral-700">·</span>
            <span className="hover:text-white transition-colors">Elle Decor</span>
            <span className="hidden sm:inline text-neutral-700">·</span>
            <span className="hover:text-white transition-colors">Wallpaper* Design Award</span>
            <span className="hidden sm:inline text-neutral-700">·</span>
            <span className="hover:text-white transition-colors">Dezeen Awards 2025</span>
          </div>
        </div>

      </div>
    </section>
  );
};
