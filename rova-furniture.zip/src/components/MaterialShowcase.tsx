import React, { useState } from 'react';
import { Sparkles, Layers, ShieldCheck, ArrowRight } from 'lucide-react';

interface MaterialItem {
  id: string;
  name: string;
  origin: string;
  category: string;
  description: string;
  image: string;
  characteristics: string[];
}

const MATERIALS: MaterialItem[] = [
  {
    id: 'mat-1',
    name: 'Roman Classic Travertine',
    origin: 'Tivoli Quarry, Rome, Italy',
    category: 'Natural Sedimentary Stone',
    description: 'Extracted from geothermal quarries south of Rome, our travertine is left with open micro-pores and subtly hand-honed with velvet water stones.',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=85',
    characteristics: ['Zero-luster matte finish', 'Unique geological mineral veining', 'Cool tactile density']
  },
  {
    id: 'mat-2',
    name: 'Italian Merino Wool Bouclé',
    origin: 'Biella Mills, Piedmont, Italy',
    category: 'Textile Architecture',
    description: 'Spun from ethical virgin merino fleece, combining looped yarns of varying diameters to create an ultra-durable, deeply textured organic embrace.',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=85',
    characteristics: ['50,000+ Martindale rub count', 'Natural lanolin stain resilience', 'Breathable thermal regulation']
  },
  {
    id: 'mat-3',
    name: 'Smoked European White Oak',
    origin: 'Spessart Forest, Bavaria',
    category: 'FSC-Certified Solid Hardwood',
    description: 'Fumed with traditional ammonia-free vapor chambers to draw rich dark chocolate tannins deep into the heartwood grain without artificial stains.',
    image: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=800&q=85',
    characteristics: ['Solid quarter-sawn stability', 'Organic beeswax sealant', 'Deep through-body coloration']
  },
  {
    id: 'mat-4',
    name: 'Hand-Patinated Champagne Brass',
    origin: 'Porto Metal Atelier, Portugal',
    category: 'Architectural Alloys',
    description: 'Solid billet brass spun on vintage lathes and hand-brushed with fine abrasive pads before receiving an invisible micro-crystalline anti-tarnish coat.',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=85',
    characteristics: ['Solid unlacquered metal weight', 'Warm golden luminescence', 'Zero visible casting seams']
  }
];

export const MaterialShowcase: React.FC = () => {
  const [activeMaterial, setActiveMaterial] = useState<MaterialItem>(MATERIALS[0]);

  return (
    <section id="materials" className="py-20 lg:py-28 bg-[#F9F6F0] border-b border-[#E6DFD5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE8DD] text-[#7A644C] text-[11px] uppercase tracking-[0.2em] font-semibold mb-3">
              <Layers className="w-3.5 h-3.5" />
              <span>Material Provenance</span>
            </div>
            <h2 className="font-serif-heading text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1A1A] tracking-tight">
              Raw Minerals & <br />
              <span className="italic font-serif-heading text-[#8C7355]">Honest Textures</span>
            </h2>
          </div>
          <p className="font-sans-body text-sm text-[#1A1A1A]/70 max-w-md font-light leading-relaxed">
            Every material in the Rova catalog is selected for its sensory richness, durability, and ability to age gracefully alongside your life.
          </p>
        </div>

        {/* 4 Materials Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {MATERIALS.map((mat) => {
            const isSelected = activeMaterial.id === mat.id;

            return (
              <div
                key={mat.id}
                onClick={() => setActiveMaterial(mat)}
                className={`cursor-pointer group rounded-[24px] overflow-hidden transition-all duration-300 border flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#FAF7F2] border-[#8C7355] ring-2 ring-[#8C7355] ring-offset-2 ring-offset-[#F9F6F0] shadow-xl'
                    : 'bg-[#FAF7F2] border-[#E2D8CC] hover:border-[#C5A880] shadow-xs'
                }`}
              >
                {/* Image */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#E2D8CC]">
                  <img
                    src={mat.image}
                    alt={mat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-full bg-[#1A1A1A]/80 backdrop-blur-xs text-[#F9F6F0] text-[10px] uppercase tracking-wider font-semibold">
                      {mat.category.split(' ')[0]}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-[#8C7355] font-semibold">
                      {mat.origin}
                    </p>
                    <h3 className="font-serif-heading text-xl font-medium text-[#1A1A1A] mt-1">
                      {mat.name}
                    </h3>
                    <p className="text-xs text-[#1A1A1A]/70 font-sans-body mt-2 line-clamp-2">
                      {mat.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#E6DFD5] flex items-center justify-between text-xs text-[#8C7355] font-medium">
                    <span>Inspect Texture</span>
                    <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
