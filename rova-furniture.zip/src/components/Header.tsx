import React, { useState, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X, ArrowRight, Heart, Sparkles } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  cart: CartItem[];
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cart,
  onOpenCart,
  onOpenSearch,
  onNavigate
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAnnouncement, setShowAnnouncement] = useState(true);

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', target: 'hero' },
    { label: 'Collection', target: 'collection' },
    { label: 'Craft & Design', target: 'craft' },
    { label: 'Materials', target: 'materials' },
    { label: 'Reviews', target: 'reviews' },
    { label: 'FAQ', target: 'faq' }
  ];

  const handleLinkClick = (target: string) => {
    setMobileMenuOpen(false);
    onNavigate(target);
  };

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300">
      {/* Top Luxury Announcement Bar */}
      {showAnnouncement && (
        <div className="bg-[#1A1A1A] text-[#F9F6F0] py-2 px-4 text-xs font-sans-body border-b border-[#2D2D2D] relative overflow-hidden">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex-1 flex items-center justify-center gap-3 tracking-wider text-[11px] sm:text-xs">
              <span className="inline-flex items-center gap-1.5 text-[#C5A880]">
                <Sparkles className="w-3 h-3 animate-pulse" />
                <span>The 2026 Collection</span>
              </span>
              <span className="hidden md:inline text-neutral-500">|</span>
              <span className="text-neutral-300">Complimentary White-Glove Installation & Insured Global Shipping</span>
              <span className="hidden sm:inline-block underline cursor-pointer text-[#C5A880] hover:text-white transition-colors" onClick={() => handleLinkClick('collection')}>
                Explore Capsule
              </span>
            </div>
            <button
              onClick={() => setShowAnnouncement(false)}
              className="text-neutral-400 hover:text-white text-xs p-1 ml-2 transition-colors"
              aria-label="Dismiss announcement"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Navigation Bar */}
      <nav
        className={`w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F9F6F0]/90 backdrop-blur-md shadow-xs border-b border-[#E6DFD5]'
            : 'bg-[#F9F6F0] border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12 h-20 flex items-center justify-between">
          {/* Logo on the left */}
          <div className="flex items-center">
            <button
              onClick={() => handleLinkClick('hero')}
              className="group flex items-baseline gap-1 focus:outline-none"
            >
              <span className="font-serif-heading text-3xl sm:text-4xl tracking-tight font-semibold text-[#1A1A1A] group-hover:text-[#8C7355] transition-colors">
                Rova
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A880] inline-block mb-1 group-hover:scale-125 transition-transform" />
            </button>
            <span className="hidden lg:inline-block ml-4 text-[10px] uppercase tracking-[0.25em] text-[#8C7355] font-medium border-l border-[#D9D2C7] pl-4">
              Atelier Living
            </span>
          </div>

          {/* Centered Navigation Links */}
          <div className="hidden md:flex items-center space-x-8 lg:space-x-10">
            {navLinks.map((link) => (
              <button
                key={link.target}
                onClick={() => handleLinkClick(link.target)}
                className="text-sm tracking-wide font-sans-body text-[#1A1A1A]/80 hover:text-[#1A1A1A] hover:font-medium transition-all relative py-1 group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#1A1A1A] group-hover:w-full transition-all duration-300 ease-out" />
              </button>
            ))}
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-3 sm:space-x-5">
            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="p-2.5 rounded-full text-[#1A1A1A]/80 hover:text-[#1A1A1A] hover:bg-[#EFE9DE] transition-colors"
              aria-label="Search collection"
              title="Search collection"
            >
              <Search className="w-4.5 h-4.5" />
            </button>

            {/* Shopping Bag Trigger */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 rounded-full text-[#1A1A1A] hover:bg-[#EFE9DE] transition-colors flex items-center gap-2"
              aria-label="Shopping bag"
              title="Shopping bag"
            >
              <ShoppingBag className="w-4.5 h-4.5" />
              {totalCartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#1A1A1A] text-[#F9F6F0] text-[10px] font-semibold w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#F9F6F0]">
                  {totalCartCount}
                </span>
              )}
            </button>

            {/* Hamburger Menu Toggle (Mobile & Tablet) */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-full text-[#1A1A1A] hover:bg-[#EFE9DE] transition-colors md:hidden focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Direct Consultation / Inquiry Button (Desktop) */}
            <button
              onClick={() => handleLinkClick('faq')}
              className="hidden lg:inline-flex items-center gap-2 text-xs font-medium tracking-wider uppercase px-4 py-2.5 rounded-full border border-[#1A1A1A]/20 hover:border-[#1A1A1A] text-[#1A1A1A] transition-all hover:bg-[#1A1A1A] hover:text-[#F9F6F0]"
            >
              <span>Concierge</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-[80px] z-50 bg-[#F9F6F0] border-t border-[#E6DFD5] md:hidden flex flex-col justify-between p-8 animate-fadeIn">
          <div className="flex flex-col space-y-6 pt-4">
            <span className="text-[11px] uppercase tracking-[0.25em] text-[#8C7355] font-semibold">
              Explore Rova Atelier
            </span>
            {navLinks.map((link) => (
              <button
                key={link.target}
                onClick={() => handleLinkClick(link.target)}
                className="text-left font-serif-heading text-2xl text-[#1A1A1A] hover:text-[#C5A880] transition-colors flex items-center justify-between group"
              >
                <span>{link.label}</span>
                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all text-[#C5A880]" />
              </button>
            ))}
          </div>

          <div className="border-t border-[#E6DFD5] pt-6 space-y-4">
            <div className="text-xs text-neutral-600 font-sans-body">
              <p className="font-semibold text-[#1A1A1A]">Rova Flagship Showroom</p>
              <p>Via Montenapoleone 24, Milan & Mercer St, New York</p>
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSearch();
              }}
              className="w-full py-3.5 px-4 bg-[#1A1A1A] text-[#F9F6F0] rounded-full text-xs font-medium tracking-wider uppercase flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" />
              <span>Search Entire Catalog</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
