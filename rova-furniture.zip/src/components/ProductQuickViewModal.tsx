import React, { useState } from 'react';
import { X, Star, ShoppingBag, Check, ShieldCheck, Truck, Sparkles, RefreshCw } from 'lucide-react';
import { Product } from '../types';

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, selectedColor: string) => void;
}

export const ProductQuickViewModal: React.FC<ProductQuickViewModalProps> = ({
  product,
  onClose,
  onAddToCart
}) => {
  if (!product) return null;

  const [selectedColor, setSelectedColor] = useState<string>(product.colorOptions[0].name);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number>(0);
  const [isAdded, setIsAdded] = useState<boolean>(false);

  const images = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];

  const handleAdd = () => {
    onAddToCart(product, selectedColor);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 overflow-y-auto bg-black/60 backdrop-blur-xs animate-fadeIn">
      {/* Backdrop click close */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal Box */}
      <div className="relative bg-[#FAF7F2] w-full max-w-4xl rounded-[28px] overflow-hidden shadow-2xl border border-[#DFD3C2] z-10 flex flex-col md:flex-row max-h-[90vh]">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-[#F9F6F0]/90 text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white transition-colors flex items-center justify-center shadow-md"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left: Gallery & Hero Image */}
        <div className="w-full md:w-1/2 p-6 bg-[#EDE6DD] flex flex-col justify-between">
          <div className="relative aspect-[4/4.2] w-full rounded-[20px] overflow-hidden bg-[#E2D8CC] shadow-inner mb-4">
            <img
              src={images[selectedImageIndex] || product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.badge && (
              <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#1A1A1A] text-[#F9F6F0] text-[10px] uppercase tracking-wider font-semibold">
                {product.badge}
              </span>
            )}
          </div>

          {/* Thumbnail Gallery */}
          {images.length > 1 && (
            <div className="flex items-center space-x-2.5 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-14 h-14 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImageIndex === idx
                      ? 'border-[#8C7355] ring-2 ring-[#8C7355]/30'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Details, Options, & Action */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            
            {/* Category & Star rating */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#8C7355]">
                {product.collection}
              </span>
              <div className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-[#C5A880] text-[#C5A880]" />
                <span className="font-semibold text-xs text-[#1A1A1A]">{product.rating}</span>
                <span className="text-neutral-400 text-[11px]">({product.reviewCount} reviews)</span>
              </div>
            </div>

            {/* Title & Price */}
            <div>
              <h3 className="font-serif-heading text-2xl sm:text-3xl font-medium text-[#1A1A1A]">
                {product.name}
              </h3>
              <p className="text-xs text-[#8C7355] mt-0.5">{product.subtitle}</p>
              
              <div className="mt-3 flex items-baseline gap-3">
                <span className="font-serif-heading text-2xl font-semibold text-[#1A1A1A]">
                  ${product.price.toLocaleString()} USD
                </span>
                {product.originalPrice && (
                  <span className="text-sm line-through text-neutral-400">
                    ${product.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            {/* Description */}
            <p className="font-sans-body text-xs sm:text-sm text-[#1A1A1A]/75 font-light leading-relaxed">
              {product.description}
            </p>

            {/* Material & Dimensions Specs */}
            <div className="space-y-2 py-3 border-y border-[#E6DFD5] text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-500">Dimensions:</span>
                <span className="font-medium text-[#1A1A1A] text-right">{product.dimensions}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Primary Material:</span>
                <span className="font-medium text-[#1A1A1A] text-right">{product.material}</span>
              </div>
            </div>

            {/* Color Finishes */}
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-neutral-600">
                Selected Finish: <span className="text-[#1A1A1A] font-bold">{selectedColor}</span>
              </span>
              <div className="flex items-center space-x-3">
                {product.colorOptions.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color.name)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs transition-all ${
                      selectedColor === color.name
                        ? 'border-[#8C7355] bg-[#EFE8DD] font-semibold text-[#1A1A1A]'
                        : 'border-[#DFD3C2] bg-transparent text-[#1A1A1A]/70 hover:bg-[#EFE8DD]'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-neutral-300"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span>{color.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Architectural Features */}
            <div className="space-y-1.5">
              <span className="text-xs uppercase tracking-wider font-semibold text-neutral-600">
                Key Features:
              </span>
              <ul className="space-y-1 text-xs text-[#1A1A1A]/80">
                {product.features.map((feat, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#8C7355]" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Bottom Actions */}
          <div className="space-y-3 pt-4">
            <button
              onClick={handleAdd}
              className={`w-full py-4 px-6 rounded-full text-xs uppercase font-medium tracking-wider flex items-center justify-center gap-2 transition-all duration-300 shadow-md ${
                isAdded
                  ? 'bg-[#435334] text-white'
                  : 'bg-[#1A1A1A] text-[#F9F6F0] hover:bg-[#333333]'
              }`}
            >
              {isAdded ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Added to Shopping Bag</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-4 h-4 text-[#C5A880]" />
                  <span>Add to Bag — ${product.price.toLocaleString()}</span>
                </>
              )}
            </button>

            <div className="flex items-center justify-center gap-6 text-[11px] text-neutral-500 font-sans-body">
              <span className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-[#8C7355]" />
                <span>White-Glove Insured Delivery</span>
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#8C7355]" />
                <span>Lifetime Guarantee</span>
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
