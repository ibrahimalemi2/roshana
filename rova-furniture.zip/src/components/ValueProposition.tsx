import React, { useState } from 'react';
import { Gem, Leaf, Sparkles, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { VALUE_PILLARS } from '../data/furnitureData';
import { ValuePillar } from '../types';

export const ValueProposition: React.FC = () => {
  const [activePillar, setActivePillar] = useState<ValuePillar>(VALUE_PILLARS[0]);

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Gem':
        return <Gem className="w-6 h-6" strokeWidth={1.5} />;
      case 'Leaf':
        return <Leaf className="w-6 h-6" strokeWidth={1.5} />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6" strokeWidth={1.5} />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6" strokeWidth={1.5} />;
      default:
        return <Sparkles className="w-6 h-6" strokeWidth={1.5} />;
    }
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-[#F4EFE6] border-b border-[#E6DFD5] relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E8DFD0] text-[#7A644C] text-[11px] uppercase tracking-[0.2em] font-semibold mb-3">
            <span>Our Principles</span>
          </div>
          <h2 className="font-serif-heading text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1A1A] tracking-tight">
            Crafted with Intent, <br />
            <span className="italic font-serif-heading text-[#8C7355]">Built for Generations</span>
          </h2>
          <p className="mt-4 font-sans-body text-sm sm:text-base text-[#1A1A1A]/70 font-light">
            We reject the disposable cycle of fast trends. Every Rova creation is an architectural heirloom engineered with pure sustainable integrity.
          </p>
        </div>

        {/* Value Proposition Split-Block Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {VALUE_PILLARS.map((pillar) => {
            const isSelected = activePillar.id === pillar.id;

            return (
              <div
                key={pillar.id}
                onClick={() => setActivePillar(pillar)}
                className={`group cursor-pointer rounded-[24px] p-7 transition-all duration-300 flex flex-col justify-between border relative overflow-hidden ${
                  isSelected
                    ? 'bg-[#1A1A1A] text-[#F9F6F0] border-[#1A1A1A] shadow-xl shadow-black/10'
                    : 'bg-[#FAF7F2] text-[#1A1A1A] border-[#E2D8CC] hover:bg-white hover:border-[#D5C7B3] shadow-xs'
                }`}
              >
                {/* Top Number & Vector Icon */}
                <div>
                  <div className="flex items-center justify-between mb-8">
                    <span
                      className={`font-serif-heading text-2xl font-light tracking-tight ${
                        isSelected ? 'text-[#C5A880]' : 'text-[#8C7355]'
                      }`}
                    >
                      {pillar.number}
                    </span>

                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-colors ${
                        isSelected
                          ? 'bg-[#2E2E2E] text-[#C5A880]'
                          : 'bg-[#EFE8DD] text-[#1A1A1A] group-hover:bg-[#E2D8CC]'
                      }`}
                    >
                      {renderIcon(pillar.iconName)}
                    </div>
                  </div>

                  {/* Title & Short Desc */}
                  <h3 className="font-serif-heading text-xl sm:text-2xl font-medium mb-3 leading-snug">
                    {pillar.title}
                  </h3>

                  <p
                    className={`font-sans-body text-xs sm:text-sm leading-relaxed mb-6 font-light ${
                      isSelected ? 'text-neutral-300' : 'text-[#1A1A1A]/70'
                    }`}
                  >
                    {pillar.shortDesc}
                  </p>
                </div>

                {/* Bottom Highlight Seal */}
                <div
                  className={`pt-4 border-t text-[11px] font-sans-body flex items-center justify-between ${
                    isSelected
                      ? 'border-neutral-700 text-[#C5A880]'
                      : 'border-[#E6DFD5] text-[#8C7355]'
                  }`}
                >
                  <span className="font-medium">{pillar.highlight}</span>
                  <ArrowRight
                    className={`w-3.5 h-3.5 transform transition-transform ${
                      isSelected ? 'translate-x-1' : 'group-hover:translate-x-1'
                    }`}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Deep Dive Spotlight for the active pillar */}
        <div className="mt-10 bg-[#FAF7F2] rounded-[24px] p-8 sm:p-10 border border-[#E2D8CC] shadow-md flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#8C7355] font-semibold">
              <span>Detailed Commitment</span>
              <span>·</span>
              <span>Pillar {activePillar.number}</span>
            </div>
            <h3 className="font-serif-heading text-2xl sm:text-3xl text-[#1A1A1A]">
              {activePillar.title}
            </h3>
            <p className="text-sm font-sans-body text-[#1A1A1A]/75 leading-relaxed">
              {activePillar.fullDesc}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto shrink-0">
            <div className="px-4 py-3 rounded-xl bg-[#EDE6DD] border border-[#DDD4C7] flex items-center gap-2 text-xs text-[#1A1A1A] font-medium">
              <CheckCircle2 className="w-4 h-4 text-[#8C7355]" />
              <span>Independent Lab Certified</span>
            </div>
            <div className="px-4 py-3 rounded-xl bg-[#EDE6DD] border border-[#DDD4C7] flex items-center gap-2 text-xs text-[#1A1A1A] font-medium">
              <CheckCircle2 className="w-4 h-4 text-[#8C7355]" />
              <span>Direct Atelier Provenance</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
