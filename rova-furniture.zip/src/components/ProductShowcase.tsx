import React, { useState } from 'react';
import { ShoppingBag, Eye, Heart, Star, Sparkles, Filter, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductShowcaseProps {
  products: Product[];
  onAddToCart: (product: Product, selectedColor: string) => void;
  onQuickView: (product: Product) => void;
}

export const ProductShowcase: React.FC<ProductShowcaseProps> = ({
  products,
  onAddToCart,
  onQuickView
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedColors, setSelectedColors] = useState<{ [productId: string]: string }>({});
  const [addedProductId, setAddedProductId] = useState<string | null>(null);
  const [wishlist, setWishlist] = useState<string[]>([]);

  const categories = ['All', 'Seating', 'Tables', 'Lighting', 'Storage', 'Objects'];

  const filteredProducts = activeCategory === 'All'
    ? products
    : products.filter((p) => p.category.toLowerCase() === activeCategory.toLowerCase());

  const handleColorSelect = (productId: string, colorName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedColors((prev) => ({ ...prev, [productId]: colorName }));
  };

  const handleAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    const activeColor = selectedColors[product.id] || product.colorOptions[0].name;
    onAddToCart(product, activeColor);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 1800);
  };

  const toggleWishlist = (productId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  return (
    <section id="collection" className="py-20 lg:py-28 bg-[#F9F6F0] relative border-b border-[#E6DFD5]">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 lg:mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE8DD] text-[#7A644C] text-[11px] uppercase tracking-[0.2em] font-semibold mb-3">
              <span>Curated Selection</span>
            </div>
            <h2 className="font-serif-heading text-3xl sm:text-4xl md:text-5xl font-normal text-[#1A1A1A] tracking-tight">
              Product Showcase <br />
              <span className="italic font-serif-heading text-[#8C7355]">The Luxe Collection</span>
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-xs font-sans-body transition-all duration-200 ${
                  activeCategory === category
                    ? 'bg-[#1A1A1A] text-[#F9F6F0] font-medium shadow-xs'
                    : 'bg-[#EFEAE1] text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#E5DEC7]'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Asymmetrical Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
          {filteredProducts.map((product, index) => {
            // Apply subtle asymmetrical sizing: e.g. first card or specific cards have enhanced visual weight
            const isFeatured = index === 0 || index === 4;
            const currentColor = selectedColors[product.id] || product.colorOptions[0].name;
            const isAdded = addedProductId === product.id;
            const isFavorited = wishlist.includes(product.id);

            return (
              <div
                key={product.id}
                onClick={() => onQuickView(product)}
                className={`group cursor-pointer flex flex-col justify-between bg-[#FDFCFA] rounded-[24px] p-4 sm:p-5 border border-[#E8DFCFA0] shadow-md hover:shadow-xl hover:border-[#D5C7B3] transition-all duration-500 relative overflow-hidden ${
                  isFeatured ? 'md:col-span-2 lg:col-span-1 ring-1 ring-[#E2D8CC]/50' : ''
                }`}
              >
                {/* Top Image Container */}
                <div className="relative aspect-[4/4.2] w-full rounded-[18px] overflow-hidden bg-[#ECE4D8] mb-5">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  />

                  {/* Badge */}
                  {product.badge && (
                    <div className="absolute top-3.5 left-3.5 z-10">
                      <span className="px-3 py-1 rounded-full bg-[#1A1A1A]/85 backdrop-blur-md text-[#F9F6F0] text-[10px] uppercase font-sans-body font-semibold tracking-wider shadow-xs">
                        {product.badge}
                      </span>
                    </div>
                  )}

                  {/* Wishlist Button */}
                  <button
                    onClick={(e) => toggleWishlist(product.id, e)}
                    className="absolute top-3.5 right-3.5 z-10 w-9 h-9 rounded-full bg-[#F9F6F0]/80 hover:bg-white text-[#1A1A1A] flex items-center justify-center backdrop-blur-xs transition-colors shadow-xs"
                    aria-label="Wishlist"
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        isFavorited ? 'fill-[#A86851] text-[#A86851]' : 'text-[#1A1A1A]'
                      }`}
                    />
                  </button>

                  {/* Hover Quick Action Tray */}
                  <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 z-10">
                    <button
                      onClick={(e) => handleAdd(product, e)}
                      className={`flex-1 py-3 px-4 rounded-xl text-xs font-sans-body font-medium flex items-center justify-center gap-2 shadow-lg transition-all ${
                        isAdded
                          ? 'bg-[#435334] text-white'
                          : 'bg-[#1A1A1A] text-[#F9F6F0] hover:bg-[#333333]'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added to Bag</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5 text-[#C5A880]" />
                          <span>Add to Bag</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickView(product);
                      }}
                      className="p-3 rounded-xl bg-[#F9F6F0] text-[#1A1A1A] hover:bg-white shadow-lg transition-colors"
                      title="Quick Specs"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Card Content & Clean Typography */}
                <div className="space-y-3">
                  
                  {/* Category & Rating */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[11px] uppercase tracking-[0.15em] font-semibold text-[#8C7355]">
                      {product.collection}
                    </span>
                    <div className="flex items-center gap-1 text-[#1A1A1A]">
                      <Star className="w-3 h-3 fill-[#C5A880] text-[#C5A880]" />
                      <span className="font-medium text-xs">{product.rating}</span>
                      <span className="text-neutral-400 text-[11px]">({product.reviewCount})</span>
                    </div>
                  </div>

                  {/* Product Title */}
                  <h3 className="font-serif-heading text-xl sm:text-2xl font-medium text-[#1A1A1A] group-hover:text-[#8C7355] transition-colors leading-snug">
                    {product.name}
                  </h3>

                  <p className="text-xs text-[#1A1A1A]/60 font-sans-body line-clamp-1">
                    {product.subtitle}
                  </p>

                  {/* Color Swatch Selector */}
                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center space-x-2">
                      {product.colorOptions.map((color) => (
                        <button
                          key={color.name}
                          onClick={(e) => handleColorSelect(product.id, color.name, e)}
                          title={color.name}
                          className={`w-5 h-5 rounded-full border transition-all ${
                            currentColor === color.name
                              ? 'ring-2 ring-[#8C7355] ring-offset-2 ring-offset-[#FDFCFA] scale-110'
                              : 'border-neutral-300 hover:scale-105'
                          }`}
                          style={{ backgroundColor: color.hex }}
                        />
                      ))}
                    </div>

                    {/* Price with optional original price strike */}
                    <div className="text-right">
                      <div className="flex items-baseline gap-2">
                        {product.originalPrice && (
                          <span className="text-xs line-through text-neutral-400 font-sans-body">
                            ${product.originalPrice.toLocaleString()}
                          </span>
                        )}
                        <span className="font-serif-heading text-lg font-semibold text-[#1A1A1A]">
                          ${product.price.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

        {/* Bottom Bespoke Commission Banner */}
        <div className="mt-16 p-8 rounded-[24px] bg-[#EDE6DD] border border-[#DDD4C7] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F9F6F0] flex items-center justify-center text-[#8C7355] shadow-xs">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-heading text-xl font-medium text-[#1A1A1A]">
                Need Custom Dimensions or Bespoke Fabric Swatches?
              </h4>
              <p className="text-xs sm:text-sm text-[#1A1A1A]/70 font-sans-body">
                Our Milan studio crafts custom dimensional adaptations and ships physical mineral & textile sample kits.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              const faqSection = document.getElementById('faq');
              faqSection?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-6 py-3 rounded-full bg-[#1A1A1A] text-[#F9F6F0] text-xs uppercase font-medium tracking-wider hover:bg-[#333333] transition-colors shrink-0"
          >
            Request Atelier Consultation
          </button>
        </div>

      </div>
    </section>
  );
};
