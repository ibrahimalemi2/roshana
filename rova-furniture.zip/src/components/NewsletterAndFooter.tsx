import React, { useState } from 'react';
import { ArrowRight, Check, Instagram, Globe, Sparkles, Shield, Heart } from 'lucide-react';

export const NewsletterAndFooter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [currency, setCurrency] = useState('USD ($)');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setIsSubscribed(true);
    setTimeout(() => {
      setEmail('');
    }, 2500);
  };

  const footerLinks = {
    Collection: [
      { label: 'Luxe Seating', href: '#collection' },
      { label: 'Architectural Tables', href: '#collection' },
      { label: 'Ambient Lighting', href: '#collection' },
      { label: 'Smoked Wood Storage', href: '#collection' },
      { label: 'Bespoke Commissions', href: '#faq' }
    ],
    Services: [
      { label: 'Trade & Architect Program', href: '#faq' },
      { label: 'White-Glove Installation', href: '#services' },
      { label: 'Physical Material Swatches', href: '#materials' },
      { label: '3D Spatial Planning', href: '#craft' },
      { label: 'Atelier Restoration', href: '#services' }
    ],
    Atelier: [
      { label: 'About Rova', href: '#hero' },
      { label: 'Milan & Copenhagen Studios', href: '#craft' },
      { label: 'Sustainability & FSC Woods', href: '#services' },
      { label: 'Press & Monographs', href: '#reviews' },
      { label: 'Careers at Rova', href: '#faq' }
    ],
    Concierge: [
      { label: 'Client Assistance', href: '#faq' },
      { label: 'Order Tracking & Freight', href: '#faq' },
      { label: 'Warranty & Care Guide', href: '#faq' },
      { label: 'Schedule Showroom Visit', href: '#faq' }
    ]
  };

  return (
    <footer className="bg-[#141414] text-[#F9F6F0] relative overflow-hidden border-t border-[#262626]">
      
      {/* Upper Newsletter Section */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-20 pb-16 border-b border-[#262626]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          <div className="lg:col-span-6 space-y-3">
            <span className="text-[11px] uppercase tracking-[0.25em] text-[#C5A880] font-semibold">
              The Rova Gazette
            </span>
            <h3 className="font-serif-heading text-3xl sm:text-4xl text-white font-normal">
              Private Releases & <br />
              <span className="italic font-serif-heading text-[#C5A880]">Design Monographs</span>
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 font-sans-body font-light max-w-md">
              Receive invitations to private capsule debuts, architectural case studies, and limited edition travertine and bouclé releases.
            </p>
          </div>

          <div className="lg:col-span-6">
            <form onSubmit={handleSubscribe} className="space-y-3">
              <div className="relative flex items-center">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address for private invitations"
                  required
                  className="w-full bg-[#1F1F1F] text-[#F9F6F0] placeholder-neutral-500 text-xs sm:text-sm px-6 py-4 rounded-full border border-neutral-700 focus:border-[#C5A880] focus:outline-none transition-colors pr-14"
                />
                <button
                  type="submit"
                  aria-label="Subscribe to newsletter"
                  className="absolute right-2 w-11 h-11 rounded-full bg-[#C5A880] text-[#141414] hover:bg-white flex items-center justify-center transition-all duration-300 shadow-md"
                >
                  {isSubscribed ? <Check className="w-5 h-5 text-[#141414]" /> : <ArrowRight className="w-5 h-5" />}
                </button>
              </div>

              {isSubscribed && (
                <div className="flex items-center gap-2 text-xs text-[#C5A880] animate-fadeIn">
                  <Check className="w-3.5 h-3.5" />
                  <span>Thank you. Your invitation to the private catalogue has been sent.</span>
                </div>
              )}

              <p className="text-[11px] text-neutral-500 font-sans-body">
                We respect your tranquility. Unsubscribe at any moment. Zero spam.
              </p>
            </form>
          </div>

        </div>
      </div>

      {/* Main Footer Links & Brand Section */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-2 md:grid-cols-12 gap-10">
          
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-4 space-y-6">
            <div className="flex items-baseline gap-1">
              <span className="font-serif-heading text-4xl font-semibold tracking-tight text-white">
                Rova
              </span>
              <span className="w-2 h-2 rounded-full bg-[#C5A880] inline-block mb-1" />
            </div>

            <p className="text-xs text-neutral-400 font-sans-body font-light leading-relaxed max-w-sm">
              An international design atelier devoted to sculptural furniture, natural stone monoliths, and tactile craftsmanship that calms the human spirit.
            </p>

            {/* Social Media Icons */}
            <div className="flex items-center space-x-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1F1F1F] hover:bg-[#C5A880] hover:text-[#141414] text-neutral-300 flex items-center justify-center transition-colors text-xs"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://pinterest.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1F1F1F] hover:bg-[#C5A880] hover:text-[#141414] text-neutral-300 flex items-center justify-center transition-colors text-xs font-serif-heading font-bold"
                title="Pinterest"
              >
                P
              </a>
              <a
                href="https://architecturaldigest.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1F1F1F] hover:bg-[#C5A880] hover:text-[#141414] text-neutral-300 flex items-center justify-center transition-colors text-xs font-serif-heading font-bold"
                title="Monographs"
              >
                AD
              </a>
              <a
                href="https://dezeen.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1F1F1F] hover:bg-[#C5A880] hover:text-[#141414] text-neutral-300 flex items-center justify-center transition-colors text-xs font-serif-heading font-bold"
                title="Dezeen"
              >
                DZ
              </a>
            </div>
          </div>

          {/* Nav Columns */}
          <div className="col-span-1 md:col-span-2 space-y-4">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C5A880]">
              Collection
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              {footerLinks.Collection.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-4">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C5A880]">
              Services
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              {footerLinks.Services.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-4">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C5A880]">
              Atelier
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              {footerLinks.Atelier.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-4">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C5A880]">
              Concierge
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              {footerLinks.Concierge.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

        </div>
      </div>

      {/* Bottom Copyright & Legal Links */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-8 border-t border-[#262626] flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500 font-sans-body">
        <div>
          © {new Date().getFullYear()} Rova Atelier Living S.r.l. All rights reserved. Registered trademark.
        </div>

        {/* Currency & Region Selector */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 text-neutral-400">
            <Globe className="w-3.5 h-3.5 text-[#C5A880]" />
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="bg-transparent border-none text-neutral-400 focus:text-white text-[11px] focus:outline-none cursor-pointer"
            >
              <option value="USD ($)" className="bg-[#141414] text-white">United States (USD $)</option>
              <option value="EUR (€)" className="bg-[#141414] text-white">European Union (EUR €)</option>
              <option value="GBP (£)" className="bg-[#141414] text-white">United Kingdom (GBP £)</option>
              <option value="JPY (¥)" className="bg-[#141414] text-white">Japan (JPY ¥)</option>
            </select>
          </div>

          <div className="flex items-center space-x-4">
            <a href="#faq" className="hover:text-neutral-300 transition-colors">Privacy Policy</a>
            <span>·</span>
            <a href="#faq" className="hover:text-neutral-300 transition-colors">Terms of Atelier</a>
            <span>·</span>
            <a href="#faq" className="hover:text-neutral-300 transition-colors">Cookies</a>
          </div>
        </div>
      </div>

    </footer>
  );
};
