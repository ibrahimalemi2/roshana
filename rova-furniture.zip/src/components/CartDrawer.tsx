import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Truck, Check } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, selectedColor: string, newQty: number) => void;
  onRemoveItem: (productId: string, selectedColor: string) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout
}) => {
  if (!isOpen) return null;

  const [checkoutComplete, setCheckoutComplete] = useState(false);

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const isFreeShipping = subtotal > 1500;
  const deliveryCost = isFreeShipping ? 0 : 150;
  const total = subtotal + deliveryCost;

  const handleCheckoutClick = () => {
    setCheckoutComplete(true);
    setTimeout(() => {
      onCheckout();
      setCheckoutComplete(false);
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity" onClick={onClose} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF7F2] shadow-2xl border-l border-[#DFD3C2] flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-[#E6DFD5] flex items-center justify-between bg-[#F4EFE6]">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#8C7355]" />
              <h3 className="font-serif-heading text-2xl font-medium text-[#1A1A1A]">
                Your Shopping Bag
              </h3>
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#1A1A1A] text-[#F9F6F0] font-sans-body">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-neutral-500 hover:text-black hover:bg-[#EAE2D5] transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16 text-[#1A1A1A]/70">
                <div className="w-16 h-16 rounded-full bg-[#EDE6DD] flex items-center justify-center text-[#8C7355]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <p className="font-serif-heading text-2xl text-[#1A1A1A]">Your bag is currently empty</p>
                  <p className="text-xs font-sans-body text-neutral-500 mt-1 max-w-xs">
                    Explore our curated seating, monolithic travertine tables, and sculptural lighting.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="mt-4 px-6 py-3 rounded-full bg-[#1A1A1A] text-[#F9F6F0] text-xs uppercase font-medium tracking-wider hover:bg-[#333333] transition-colors"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              <>
                {/* Free White-Glove Indicator */}
                <div className="p-3.5 rounded-xl bg-[#EDE6DD] border border-[#DDD4C7] text-xs flex items-center gap-2.5 text-[#1A1A1A]">
                  <Truck className="w-4 h-4 text-[#8C7355] shrink-0" />
                  <span>
                    {isFreeShipping ? (
                      <strong className="text-[#3A5A40]">Complimentary White-Glove Shipping unlocked</strong>
                    ) : (
                      `Add $${(1500 - subtotal).toLocaleString()} more for free insured delivery`
                    )}
                  </span>
                </div>

                {/* Items */}
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={`${item.product.id}-${item.selectedColor}`}
                      className="p-4 rounded-2xl bg-white border border-[#E8DFCFA0] shadow-xs flex gap-4 items-center"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-20 h-20 rounded-xl object-cover bg-[#ECE4D8] shrink-0"
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-serif-heading text-base font-medium text-[#1A1A1A] truncate">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(item.product.id, item.selectedColor)}
                            className="text-neutral-400 hover:text-red-600 transition-colors p-1"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <p className="text-[11px] text-[#8C7355] font-sans-body">
                          Finish: {item.selectedColor}
                        </p>

                        <div className="flex items-center justify-between mt-3">
                          {/* Quantity selector */}
                          <div className="flex items-center border border-[#DFD3C2] rounded-lg bg-[#FAF7F2]">
                            <button
                              onClick={() =>
                                onUpdateQuantity(item.product.id, item.selectedColor, item.quantity - 1)
                              }
                              className="p-1 text-neutral-600 hover:text-black"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-medium font-sans-body text-[#1A1A1A]">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() =>
                                onUpdateQuantity(item.product.id, item.selectedColor, item.quantity + 1)
                              }
                              className="p-1 text-neutral-600 hover:text-black"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          {/* Price */}
                          <span className="font-serif-heading text-sm font-semibold text-[#1A1A1A]">
                            ${(item.product.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Footer & Checkout button */}
          {cart.length > 0 && (
            <div className="p-6 bg-[#F4EFE6] border-t border-[#E6DFD5] space-y-4">
              <div className="space-y-2 text-xs text-[#1A1A1A]/80 font-sans-body">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-medium text-[#1A1A1A]">${subtotal.toLocaleString()} USD</span>
                </div>
                <div className="flex justify-between">
                  <span>White-Glove Insured Delivery</span>
                  <span className="font-medium text-[#1A1A1A]">
                    {deliveryCost === 0 ? 'Complimentary' : `$${deliveryCost}`}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#DFD3C2] text-sm font-semibold text-[#1A1A1A]">
                  <span>Total Due</span>
                  <span className="font-serif-heading text-lg">${total.toLocaleString()} USD</span>
                </div>
              </div>

              <button
                onClick={handleCheckoutClick}
                disabled={checkoutComplete}
                className={`w-full py-4 px-6 rounded-full text-xs uppercase font-medium tracking-wider flex items-center justify-center gap-2 transition-all duration-300 shadow-md ${
                  checkoutComplete
                    ? 'bg-[#435334] text-white'
                    : 'bg-[#1A1A1A] text-[#F9F6F0] hover:bg-[#333333]'
                }`}
              >
                {checkoutComplete ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Order Reserved Successfully</span>
                  </>
                ) : (
                  <>
                    <span>Proceed to Insured Checkout</span>
                    <ArrowRight className="w-4 h-4 text-[#C5A880]" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-4 text-[10px] text-neutral-500 font-sans-body">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-[#8C7355]" />
                  <span>256-Bit Encrypted Secure Checkout</span>
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
